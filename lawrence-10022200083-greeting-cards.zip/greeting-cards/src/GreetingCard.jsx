const GreetingCard = ({ title, message }) => {
  return (
    <div className="border border-gray-300 rounded-lg p-6 m-4 max-w-xs shadow-lg bg-gray-100">
      <h2 className="text-xl font-semibold mb-4">{title}</h2>
      <p className="text-gray-600">{message}</p>
    </div>
  );
};

export default GreetingCard;

