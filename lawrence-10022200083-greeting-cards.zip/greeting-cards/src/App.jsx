import React from 'react';
import Header from './Header';  // Import Header component
import GreetingCard from './GreetingCard';  // Import GreetingCard component

const App = () => {
  const cards = [
    { title: "Happy Birthday!", message: "Wishing you a fantastic day filled with joy!" },
    { title: "Congratulations!", message: "Great job on your achievement!" },
    { title: "Thank You!", message: "Thanks for your kindness and support!" },
  ];

  return (
    <div className="font-sans p-6 bg-blue-100">
      {/* Header */}
      <Header />

      {/* Cards */}
      <div className="flex justify-center flex-wrap mt-6">
        {cards.map((card, index) => (
          <GreetingCard key={index} title={card.title} message={card.message} />
        ))}
      </div>
    </div>
  );
};

export default App;
